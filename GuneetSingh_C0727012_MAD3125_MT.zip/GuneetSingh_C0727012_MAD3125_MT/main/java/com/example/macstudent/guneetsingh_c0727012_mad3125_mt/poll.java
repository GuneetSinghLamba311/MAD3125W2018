package com.example.macstudent.guneetsingh_c0727012_mad3125_mt;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.util.*;
import android.widget.*;
import android.content.ContentValues;
import android.database.Cursor;


public class poll extends AppCompatActivity implements View.OnClickListener {

    String questions1;
    String questions2;
    String questions3;
    String heading_title;
    TextView title;
    TextView question;
    TextView link1;
    TextView link2;
    TextView link3;
    TextView link4;
    RadioButton  option1;
    RadioButton  option2;
    RadioButton  option3;
    RadioButton  option4;
    Button submit;
    DBHelper dbHelper;
    SQLiteDatabase PollDB;
    WebView web;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_poll);


        title = (TextView) findViewById(R.id.title);
        question = (TextView) findViewById(R.id.question);
        link1 = (TextView) findViewById(R.id.link1);
        link2 = (TextView) findViewById(R.id.link2);
        link3 = (TextView) findViewById(R.id.link3);
        link4 = (TextView) findViewById(R.id.link4);
        link1.setOnClickListener(this);
        link2.setOnClickListener(this);
        link3.setOnClickListener(this);
        link4.setOnClickListener(this);
        option1 = (RadioButton) findViewById(R.id.option1);
        option2 = (RadioButton) findViewById(R.id.option2);
        option3 = (RadioButton) findViewById(R.id.option3);
        option4 = (RadioButton) findViewById(R.id.option4);
        submit = (Button) findViewById(R.id.submit);
        option1.setOnClickListener(this);
        option2.setOnClickListener(this);
        option3.setOnClickListener(this);
        option4.setOnClickListener(this);
        submit.setOnClickListener(this);
        web = (WebView) findViewById(R.id.webview);

        Intent in = getIntent();
        heading_title = in.getStringExtra("title");
        questions1 = in.getStringExtra("timQues");
        questions2 = in.getStringExtra("techQues");
        questions3 = in.getStringExtra("politicsQues");
        title.setText(heading_title);
        if(heading_title.equals("Tim")) {
            question.setText(questions1);
            option1.setText("Coffee");
            option2.setText("Donuts");
            option3.setText("Bagels");
            option4.setText("Timbits");
        }
        else if (heading_title.equals("Technology")) {
            question.setText(questions2);
            option1.setText("Toronto");
            option2.setText("Ottawa");
            option3.setText("Montreal");
            option4.setText("Vancouver");
        }
        else if (heading_title.equals("Politics")) {
            question.setText(questions3);
            option1.setText("Justine Trudeau");
            option2.setText("John Abbott");
            option3.setText("Kim Campbell");
            option4.setText("Charles Tupper");
        }


    }




    @Override
    public void onClick(View view) {


     if(view.getId() == submit.getId()) {
         insertData();
         displayData();
         Toast.makeText(this, "DataEnteredInDatabase", Toast.LENGTH_SHORT).show();
     }
     else if (view.getId() == link1.getId()) {

         web.loadUrl("www.google.com");

     }
     else if (view.getId() == link2.getId()) {
         WebView webManual = (WebView) findViewById(R.id.webview);
         webManual.loadUrl("www.google.com");

     }
     else if (view.getId() == link3.getId()) {
         WebView webManual = (WebView) findViewById(R.id.webview);
         webManual.loadUrl("www.google.com");
     }
     else if (view.getId() == link4.getId()) {
         WebView webManual = (WebView) findViewById(R.id.webview);
         webManual.loadUrl("www.google.com");
     }
    }
    public void insertData(){
        DBHelper dbHelper = new DBHelper(getApplicationContext());
        SQLiteDatabase pollDB = dbHelper.getWritableDatabase();

        String pollTitles[] = {"Tim","Technology","Politics"};
        String questions[] = {"What is the best thing about Tim?",
                "Which is the IT hub of Canada?",
                "Who is the most famous prime minister?"
        };
        String options[][] = {{"Coffee", "Donuts", "Bagels", "Timbits"},
                {"Toronto", "Ottawa", "Montreal", "Vancouver"},
                {"Justine Trudeau","John Abbott", "Kim Campbell", "Charles Tupper"}};
        int countOptions[][] = {{0,0,0,0},{0,0,0,0},{0,0,0,0}};

        for(int i=0; i<pollTitles.length; i++) {

            ContentValues cv = new ContentValues();
            cv.put("PollTitle", pollTitles[i]);
            cv.put("Question", questions[i]);

            for(int j=0;j<4;j++) {
                cv.put("Option"+(j+1), options[i][j]);
                cv.put("CountOption"+(j+1), countOptions[i][j]);
            }

            try {
                pollDB = dbHelper.getWritableDatabase();
                pollDB.insert("Poll",null, cv);
                Log.v("Insert record", "Record inserted successfully");
            } catch (Exception e) {
                Log.e("Insert Record Error", e.getMessage());
            }
        }
        pollDB.close();
    }
    private void displayData(){

        try{
            PollDB = dbHelper.getReadableDatabase();

            String columns[] = {"PollTitle"};

            Cursor cursor = PollDB.query("Poll"
                    ,columns,null,null,
                    null,null,null);

            while (cursor.moveToNext()){
                String pollname = cursor.getString
                        (cursor.getColumnIndex("PollTitle"));



                Toast.makeText(this,pollname,
                        Toast.LENGTH_LONG).show();

            }


        }catch (Exception e){
            Log.e("RegisterActivity : ",
                    "Unable to fetch the records");
        }

        PollDB.close();

    }





}

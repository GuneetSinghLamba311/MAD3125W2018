
var counter = 1;
document.getElementById("login").addEventListener("click",function login() {
if(counter<3) {


if(document.getElementById("username").value === "admin" &&  document.getElementById("password").value ==="123456") {
window.open("calculator.html")
console.log("ok");
}
else {
counter++;
document.getElementById("username").value = counter+" trial left";
document.getElementById("password").value = counter+"  trial left";
}
}
else if(counter==3) {


  document.getElementById("username").value = "Enter Again";
  document.getElementById("password").value = "Enter Again";
}
});

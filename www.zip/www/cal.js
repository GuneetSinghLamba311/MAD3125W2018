
  document.getElementById("value1").value;
 document.getElementById("value2").value;
document.getElementById("add").addEventListener("click",
function add() {
  if (isNaN(document.getElementById("value1").value)) {
    document.getElementById("result").value = " Enter valid number";
  }
  else {
document.getElementById("result").value = parseInt(document.getElementById("value1").value) + parseInt(document.getElementById("value2").value);
}});
document.getElementById("subtract").addEventListener("click",
function sub() {
  if (isNaN(document.getElementById("value1").value)) {
    document.getElementById("result").value = " Enter valid number";
  }
  else {
document.getElementById("result").value = parseInt(document.getElementById("value1").value) - parseInt(document.getElementById("value2").value);
}});
document.getElementById("divide").addEventListener("click",
function div() {
  if (isNaN(document.getElementById("value1").value)) {
    document.getElementById("result").value = " Enter valid number";
  }
  else {
document.getElementById("result").value = parseInt(document.getElementById("value1").value) / parseInt(document.getElementById("value2").value);
}});
document.getElementById("multiply").addEventListener("click",
function mul() {
  if (isNaN(document.getElementById("value1").value)) {
    document.getElementById("result").value = " Enter valid number";
  }
  else {
document.getElementById("result").value = parseInt(document.getElementById("value1").value) * parseInt(document.getElementById("value2").value);
}});
document.getElementById("clear").addEventListener("click",
function clear() {
document.getElementById("value1").value = "";
document.getElementById("value2").value = "";
document.getElementById("result").value = "";
});

package com.example.guneetsinghlamba.sgnparking;


import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DBHelper extends SQLiteOpenHelper {    // extends Database class.


    private final static  String DB_NAME = "SGNParking";
    private final static  String Table_NAME = "NEWUSERS";
    private final static  String Parking_Table = "PARKING";


    public DBHelper(Context context) {
        super(context, DB_NAME, null,2);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {

            String CREATE_TABLE = "CREATE TABLE " +
                    Table_NAME + " (Id INTEGER Primary key AUTOINCREMENT," +
                    "Email VARCHAR(100)," +
                    "Password VARCHAR(30)," +
                    "Confirm_Password VARCHAR(30)," + "PhoneNumber VARCHAR(30)," + "DOB VARCHAR(30)," + "CarPlateNumber VARCHAR(30))";

            String Create_TABLE_Parking = "CREATE TABLE " +
                    Parking_Table + " (Id INTEGER Primary key AUTOINCREMENT," +
                    "CarName VARCHAR(100)," +
                    "Location VARCHAR(30)," +
                    "Price VARCHAR(30)," + "Time VARCHAR(30)," + "CardNumber VARCHAR(30))";

            Log.v("On create table: ", CREATE_TABLE);
            Log.v("On create table: ", Create_TABLE_Parking);
            db.execSQL(CREATE_TABLE);
            db.execSQL(Create_TABLE_Parking);
        } catch (Exception ex) {
            Log.e("DBHelper", ex.getMessage());
        }

    }



    @Override
    public void onUpgrade(SQLiteDatabase db, int olderVersion, int newerVersion) {
        try {

            db.execSQL("DROP TABLE IF EXISTS " + Table_NAME);
            db.execSQL("DROP TABLE IF EXISTS " + Parking_Table);
            onCreate(db);
        } catch(Exception ex)
        {
            Log.e("DBHelper", ex.getMessage());
        }
    }
}


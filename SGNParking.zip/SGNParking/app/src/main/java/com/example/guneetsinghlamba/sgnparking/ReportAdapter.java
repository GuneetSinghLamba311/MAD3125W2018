package com.example.guneetsinghlamba.sgnparking;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by jkp on 2018-04-15.
 */

public class ReportAdapter extends BaseAdapter {

    LayoutInflater inflater;
    SQLiteDatabase SGNParking;
    DBHelper dbHelper;
    Context context;
    String[] loc;
    String[] time;
    String[] price;
    ArrayList<String> locations;
    ArrayList<String> times;
    ArrayList<String> prices;

    ReportAdapter(Context context) {
        inflater = (LayoutInflater.from(context));

    }

    @Override
    public int getCount() {
        return loc.length;
    }

    @Override
    public Object getItem(int i) {
        return i;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        view = inflater.inflate(R.layout.custom, null);

        TextView userloc = (TextView) view.findViewById(R.id.locationID);
        TextView userprice = (TextView) view.findViewById(R.id.timeID);
        TextView usertime = (TextView) view.findViewById(R.id.priceID);
        dbHelper = new DBHelper(context);
        try {
            SGNParking = dbHelper.getReadableDatabase();
            String columns[] = {"CarName","Location", "Price", "Time","CardNumber"};


            Cursor cursor = SGNParking.query("PARKING", columns, null, null, null, null, null);

            while (cursor.moveToNext()) {

                locations.add(cursor.getString(cursor.getColumnIndex("Location")));
                times.add(cursor.getString(cursor.getColumnIndex("TIME")));
                prices.add(cursor.getString(cursor.getColumnIndex("Price")));
            }
            loc = (String[]) locations.toArray();
            time = (String[]) times.toArray();
            price = (String[]) prices.toArray();

            }catch(Exception e){
            Log.e("Error getting Data", e.getMessage());
        }
             SGNParking.close();


        userloc.setText(loc[i]);
        userprice.setText(time[i]);
        usertime.setText(price[i]);

                view.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Toast.makeText(context, "item clicked ", Toast.LENGTH_LONG).show();
                    }
                });

                return view;

        }
    }




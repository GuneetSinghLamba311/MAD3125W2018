package com.example.guneetsinghlamba.sgnparking;

import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class SignUpActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnSubmit;
    TextView txtDOB;
    DBHelper dbHelper;
    SQLiteDatabase SGNParking;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        btnSubmit = findViewById(R.id.confirm);

        btnSubmit.setOnClickListener(this);
        txtDOB = findViewById(R.id.dob);
        txtDOB.setOnClickListener(this);
        dbHelper = new DBHelper(this);
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == btnSubmit.getId()) {
            insertUser();
            displayData();
        } else if (view.getId() == txtDOB.getId()) {
            Calendar calendar = Calendar.getInstance();
            new DatePickerDialog(this, datePickerListener, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show();
        }
    }

    DatePickerDialog.OnDateSetListener datePickerListener = new DatePickerDialog.OnDateSetListener() {

        @Override
        public void onDateSet(DatePicker datePicker, int year, int month, int day) {
            String yy = String.valueOf(year);
            String mm = String.valueOf(month + 1);
            String dd = String.valueOf(day);
            if (month < 10) {
                mm = "0" + mm;
            }
            if (day < 10) {
                dd = "0" + dd;
            }
            txtDOB.setText(mm + "-" + dd + "-" + yy);

        }
    };

    private void insertUser() {
        EditText edtEmail = findViewById(R.id.email);
        EditText edtPassword = findViewById(R.id.password);
        EditText edtConfPassword = findViewById(R.id.confpassword);
        EditText edtPhone = findViewById(R.id.phone);
        EditText carplate = findViewById(R.id.CarPlateNumber);


        TextView txtDOB = (TextView) findViewById(R.id.dob);
        String email = edtEmail.getText().toString();
        String password = edtPassword.getText().toString();
        String confirmpassword = edtConfPassword.getText().toString();
        String phone = edtPhone.getText().toString();
        String dob = txtDOB.getText().toString();
        String CarPlateNumber = carplate.getText().toString();
        ContentValues cv = new ContentValues(); // insert values into database.
        cv.put("Email",email);
        cv.put("Password",password);
        cv.put("Confirm_Password",password);
        cv.put("PhoneNumber",phone);
        cv.put("DOB",dob);
        cv.put("CarPlateNumber",CarPlateNumber);



        try {
            SGNParking = dbHelper.getWritableDatabase();

            SGNParking.insert("NEWUSERS",null,cv);
            Log.v("InsertUser","Successful");

        }catch (Exception ex) {

            Log.e("InsertUser", ex.getMessage());

        }
        SGNParking.close();
    }



    private void displayData() {



        try {
            SGNParking = dbHelper.getReadableDatabase();
            String columns[] = {"Email","Password","Confirm_Password","PhoneNumber","DOB","CarPlateNumber"};


            Cursor cursor = SGNParking.query("NEWUSERS", columns, null, null, null, null,null);

            while(cursor.moveToNext()){


                String email = cursor.getString(cursor.getColumnIndex("Email"));

                String password = cursor.getString(cursor.getColumnIndex("Password"));
                String conPassword = cursor.getString(cursor.getColumnIndex("Confirm_Password"));
                String Phone = cursor.getString(cursor.getColumnIndex("PhoneNumber"));
                String birthDate = cursor.getString(cursor.getColumnIndex("DOB"));
                String userInfo =   email + "\n" + Phone   + "\n" + birthDate;
                Toast.makeText(this,userInfo,Toast.LENGTH_LONG).show();
                Intent login = new Intent(this,Loginpage.class);
                startActivity(login);
            }



        }catch(Exception e) {
            Log.e("RegisterActivity",e.getMessage());
        }
    }

}

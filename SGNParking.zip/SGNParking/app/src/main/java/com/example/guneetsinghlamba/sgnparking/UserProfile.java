package com.example.guneetsinghlamba.sgnparking;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;


public class UserProfile extends AppCompatActivity implements View.OnClickListener {


    Button update;
    TextView useremail;
    TextView userPassword;
    TextView userNumber;
    TextView userCarNumber;
    String email;
    DBHelper dbHelper;
    SQLiteDatabase SGNParking;
    String Useremail;
    String password;
    String Phone;
    String carnumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);
        useremail = (TextView) findViewById(R.id.username);
        userPassword = (TextView) findViewById(R.id.userpassword);
        userNumber = (TextView) findViewById(R.id.usernumber);
        userCarNumber = (TextView) findViewById(R.id.usercarnumber);
        dbHelper = new DBHelper(this);
        update = (Button) findViewById(R.id.update);
        update.setOnClickListener(this);
        SharedPreferences sp = getSharedPreferences("com.example.guneetsinghlamba.sgnparking", Context.MODE_PRIVATE);
        email = sp.getString("useremail", "Data Missing");
        System.out.println(email);
        displayData();

    }

    private void displayData() {
        try {
            SGNParking = dbHelper.getReadableDatabase();
            String columns[] = {"Email", "Password", "Confirm_Password", "PhoneNumber", "DOB", "CarPlateNumber"};


            Cursor cursor = SGNParking.query("NEWUSERS", columns, "Email = ?", new String[]{email}, null, null, null);

            while (cursor.moveToNext()) {


                Useremail = cursor.getString(cursor.getColumnIndex("Email"));

                password = cursor.getString(cursor.getColumnIndex("Password"));

                Phone = cursor.getString(cursor.getColumnIndex("PhoneNumber"));
                carnumber = cursor.getString(cursor.getColumnIndex("CarPlateNumber"));
                useremail.setText(Useremail);
                userPassword.setText(password);
                userNumber.setText(Phone);
                userCarNumber.setText(carnumber);
            }


        } catch (Exception e) {
            Log.e("RegisterActivity", e.getMessage());
        }
    }

    @Override
    public void onClick(View view) {
        ContentValues cv = new ContentValues(); // insert values into database.
        cv.put("Email", email);
        cv.put("Password", password);

        cv.put("PhoneNumber", Phone);

        cv.put("CarPlateNumber", carnumber);
        if (view.getId() == update.getId()) {

            try {
                SGNParking = dbHelper.getWritableDatabase();



               SGNParking.update("NEWUSERS",cv,null,null);

            } catch (Exception e) {
                Log.e("InsertUser", e.getMessage());
            }

        }
    }
}

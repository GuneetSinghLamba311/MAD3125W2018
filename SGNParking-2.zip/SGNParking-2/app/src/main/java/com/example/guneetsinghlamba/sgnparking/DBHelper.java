package com.example.guneetsinghlamba.sgnparking;


import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DBHelper extends SQLiteOpenHelper {    // extends Database class.


    private final static  String DB_NAME = "SGNParking";
    private final static  String Table_NAME = "NEWUSERS";

    public DBHelper(Context context) {
        super(context, DB_NAME, null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {

            String CREATE_TABLE = "CREATE TABLE " +
                    Table_NAME + " (Id INTEGER Primary key AUTOINCREMENT," +
                    "Email VARCHAR(100)," +
                    "Password VARCHAR(30)," +
                    "Confirm_Password VARCHAR(30)," + "PhoneNumber VARCHAR(30)," + "DOB VARCHAR(30)," + "CarPlateNumber VARCHAR(30))";

            Log.v("On create table: ",CREATE_TABLE);
            db.execSQL(CREATE_TABLE);
        }
        catch (Exception ex) {
            Log.e("DBHelper", ex.getMessage());
        }

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int olderVersion, int newerVersion) {
        try {

            db.execSQL("DROP TABLE IF EXISTS " + Table_NAME);
            onCreate(db);
        } catch(Exception ex)
        {
            Log.e("DBHelper", ex.getMessage());
        }
    }
}


package com.example.guneetsinghlamba.sgnparkingassistant;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.*;
import android.view.View;

public class LoginPage extends AppCompatActivity implements View.OnClickListener {


    Button SignIn;
    Button SignUp;
    EditText Username;
    EditText Password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);
        SignIn = (Button)findViewById(R.id.button);
        SignUp = (Button) findViewById(R.id.button2);
        SignIn.setOnClickListener(this);
        SignUp.setOnClickListener(this);
        Username = (EditText) findViewById(R.id.editText);
        Password = (EditText) findViewById(R.id.editText2);
        }

    @Override
    public void onClick(View view) {

        if(view.getId() == SignIn.getId()) {

        }


    }



}

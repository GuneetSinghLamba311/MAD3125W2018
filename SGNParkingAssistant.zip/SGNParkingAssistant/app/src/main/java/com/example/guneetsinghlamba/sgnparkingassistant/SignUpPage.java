package com.example.guneetsinghlamba.sgnparkingassistant;


import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.*;
import android.view.View;

public class SignUpPage extends AppCompatActivity implements View.OnClickListener {

    EditText Email;
    EditText Password;
    EditText ConfirmPassword;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    Email = (EditText) findViewById(R.id.editText3);
    Password = (EditText) findViewById(R.id.editText6);
    ConfirmPassword = (EditText) findViewById(R.id.editText7);

    }

    @Override
    public void onClick(View view) {

    }
}

package com.jk.thunder;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class ReceiptActivity extends AppCompatActivity {

    @Override
    public void onBackPressed() {

    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receipt);

        SharedPreferences sp = getSharedPreferences("com.jk.thunder.shared", Context.MODE_PRIVATE);
        String data = sp.getString("CarPlate","Data Missing");
        data += " " + sp.getString("Company", "Data Missing");
        data += " " + sp.getString("Payment", "Data Missing");
        data += " " + sp.getString("Lot", "Data Missing");
        data += " " + sp.getString("Spot", "Data Missing");
        data += " " + sp.getString("DateTime", "Data Missing");
        data += " " + String.valueOf(sp.getInt("Amount", 0));

        TextView txtData = (TextView) findViewById(R.id.txtData);
        txtData.setText(data);
    }
}

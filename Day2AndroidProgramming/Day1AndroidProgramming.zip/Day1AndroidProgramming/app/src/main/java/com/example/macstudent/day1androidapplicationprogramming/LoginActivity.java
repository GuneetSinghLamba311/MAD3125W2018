package com.example.macstudent.day1androidapplicationprogramming;

import android.content.Intent;
import android.content.Intent.*;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.widget.*;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnLogin;
    Button btnRegister;
    EditText editUsername;
    EditText editPassword;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        btnLogin = (Button) findViewById(R.id.button);
        btnRegister = (Button) findViewById(R.id.button2);
        btnLogin.setOnClickListener(this); // Relate to current view.
        btnRegister.setOnClickListener(this); // Relate to current view.
        editUsername = (EditText) findViewById(R.id.editText);
        editPassword = (EditText) findViewById(R.id.editText2);

    }


    @Override
    public void onClick(View view) {
    if (view.getId() == btnLogin.getId()) {
        String uname = editUsername.getText().toString();
        String passwd = editPassword.getText().toString();

        if (uname.equals("test") && passwd.equals("test")) {


            Toast.makeText(this, uname + " " + passwd, Toast.LENGTH_SHORT).show(); // Make an alert when Login button is clicked.

           Intent homeIntent = new Intent(this, homeActivity.class);
            startActivity(homeIntent);

        }
    }
    else if (view.getId() == btnRegister.getId()) {

        Toast.makeText(this, "Register Clicekd", Toast.LENGTH_SHORT).show(); // Make an alert when Register button is clicked.
        Intent register = new Intent(this, register.class);
        startActivity(register);
    }
    }
}
